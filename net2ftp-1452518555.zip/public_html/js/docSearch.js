$(document).ready(function(){
	//$(".graphg").hide();

 $("#enter").click(function(){
        $(".graphg").show();
    });
   
});